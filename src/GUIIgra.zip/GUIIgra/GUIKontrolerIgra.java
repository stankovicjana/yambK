/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//IV predavanje cas II
package GUIIgra;

import DomenskiObjekat.Korisnik;
import DomenskiObjekat.Partija;
import GUIIgra.Osluskivaci.OsluskivacSacuvajIgru;
import GUIIgra.Osluskivaci.OsluskivacZavrsiPotez;
import GUIMeni.JFX03;
import TransferObjekat.GenerickiTransferObjekat;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Random;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author user
 */
public class GUIKontrolerIgra {

    FXMLDocumentController fxcon;
    GenerickiTransferObjekat gto = new GenerickiTransferObjekat();
    Random random = new Random();

    ToggleButton[] diceButtons = new ToggleButton[6];
    int[] diceValues = new int[6];
    int rollsLeft = 3;
    boolean myTurn = false;
    boolean hasPlayedThisTurn = false;
    boolean najavaAktivna = false;
    TextField najavljenoPolje = null;
    private Server server;
    final int ROW_COUNT = 15;
    final int TOTAL_SUM_ROW_INDEX = 14;
    final int SUM_ROW_INDEX = 6;
    final int COLUMN_COUNT = 5;

    public GUIKontrolerIgra(FXMLDocumentController fxcon) {
        System.out.println("USAO U KONSTRUKTOR KONTROLER IGRE");
        this.fxcon = fxcon;
        fxcon.handleFinishGame.setOnAction(new OsluskivacSacuvajIgru(this));
        fxcon.next.setOnAction(new OsluskivacZavrsiPotez(this));
        fxcon.najava.setOnAction(e -> handleNajaviPolje());
        server = new Server(fxcon.in, fxcon.out, this.fxcon.korisnik, this);
        gto.korisnik = this.fxcon.korisnik;
    }

    public void init() {
        diceButtons[0] = fxcon.dice0;
        diceButtons[1] = fxcon.dice1;
        diceButtons[2] = fxcon.dice2;
        diceButtons[3] = fxcon.dice3;
        diceButtons[4] = fxcon.dice4;
        diceButtons[5] = fxcon.dice5;

        setMyTurn(fxcon.start);
        setupTable();
        updateRollLabel();
        updateSumLabel();

        for (ToggleButton btn : diceButtons) {
            btn.setOnAction(e -> updateSumLabel());
        }
    }

    private void updateSumLabel() {
        int sum = 0;
        for (int i = 0; i < 6; i++) {
            if (diceButtons[i].isSelected()) {
                sum += diceValues[i];
            }
        }
        fxcon.sumLabel.setText(String.valueOf(sum));
    }

    private void updateRollLabel() {
        fxcon.rollCountLabel.setText(myTurn ? String.valueOf(rollsLeft) : "Čekaj");
    }

    private void setupTable() {
        String[] columns = {"↓", "↑", "↕", "N"};
        String[] rows = {
            "1", "2", "3", "4", "5", "6", "Σ", "MAX", "MIN", "Σ",
            "KENTA", "FUL", "POKER", "JAMB", "Σ"
        };

        GridPane jambTable = fxcon.jambTable;
        jambTable.getChildren().clear();

        for (int col = 0; col < columns.length; col++) {
            Label header = new Label(columns[col]);
            jambTable.add(header, col + 1, 0);
        }

        for (int row = 0; row < rows.length; row++) {
            Label rowHeader = new Label(rows[row]);
            jambTable.add(rowHeader, 0, row + 1);

            for (int col = 0; col < columns.length; col++) {
                TextField field = new TextField();
                field.setEditable(true);
                field.setPrefWidth(50);

                // Zaključani redovi (suma redovi)
                if (row == 6 || row == 9 || row == 14) {
                    field.setEditable(false);
                } else {
                    field.setOnMouseClicked(event -> {
                        if (!myTurn || hasPlayedThisTurn || rollsLeft == 3) {
                            return;
                        }

                        if (!field.getText().isEmpty()) {
                            return;
                        }

                        int[] selected = getSelectedFiveDice();
                        if (selected.length != 5) {
                            showAlert("Izaberite tačno 5 kockica.");
                            return;
                        }

                        int rezultat = izracunajPoPolju(selected, field);
                        field.setText(String.valueOf(rezultat));

                        hasPlayedThisTurn = true;
                    });
                }

                jambTable.add(field, col + 1, row + 1);
            }
        }
    }

    private int[] getSelectedFiveDice() {
        int count = 0;
        for (ToggleButton btn : diceButtons) {
            if (btn.isSelected()) {
                count++;
            }
        }

        if (count != 5) {
            return new int[0];
        }

        int[] selected = new int[5];
        int index = 0;
        for (int i = 0; i < 6; i++) {
            if (diceButtons[i].isSelected()) {
                selected[index++] = diceValues[i];
            }
        }
        return selected;
    }

    private int izracunajPoPolju(int[] kocke, TextField polje) {
        Integer colIndex = GridPane.getColumnIndex(polje);
        Integer rowIndex = GridPane.getRowIndex(polje);
        if (colIndex == null || rowIndex == null) {
            return 0;
        }

        int red = rowIndex - 1;
        int zbir = 0;

        switch (red) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                int target = red + 1;
                for (int k : kocke) {
                    if (k == target) {
                        zbir += k;
                    }
                }
                break;
            case 7: // MAX
                for (int k : kocke) {
                    zbir += k;
                }
                break;
            case 8: // MIN
                for (int k : kocke) {
                    zbir += k;
                }
                break;
            case 10: // KENTA
                java.util.Arrays.sort(kocke);
                String s = java.util.Arrays.toString(kocke);
                if (s.equals("[1, 2, 3, 4, 5]") || s.equals("[2, 3, 4, 5, 6]")) {
                    zbir = 66;
                }
                break;
            case 11: // FUL
                if (jeFul(kocke)) {
                    zbir = 30;
                }
                break;
            case 12: // POKER
                if (jePoker(kocke)) {
                    zbir = 40;
                }
                break;
            case 13: // JAMB
                if (jeJamb(kocke)) {
                    zbir = 50;
                }
                break;
            default:
                zbir = 0;
        }

        return zbir;
    }

    private boolean jePoker(int[] kocke) {
        for (int i = 1; i <= 6; i++) {
            int count = 0;
            for (int val : kocke) {
                if (val == i) {
                    count++;
                }
            }
            if (count == 4 || count == 5) {
                return true;
            }
        }
        return false;
    }

    private boolean jeJamb(int[] kocke) {
        int first = kocke[0];
        for (int i = 1; i < kocke.length; i++) {
            if (kocke[i] != first) {
                return false;
            }
        }
        return true;
    }

    private boolean jeFul(int[] kocke) {
        java.util.Map<Integer, Integer> map = new java.util.HashMap<>();
        for (int k : kocke) {
            map.put(k, map.getOrDefault(k, 0) + 1);
        }
        return map.containsValue(3) && map.containsValue(2);
    }

    void handleNajaviPolje() {
        if (najavljenoPolje == null) {
            showAlert("Kliknite prvo na polje koje želite da najavite.");
            return;
        }
        najavaAktivna = true;
        showAlert("Najava uspešna! Sada bacite kockice za najavljeno polje.");
    }

    private void showAlert(String text) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Obaveštenje");
        alert.setHeaderText(null);
        alert.setContentText(text);
        alert.showAndWait();
    }

    public void setMyTurn(boolean turn) {
        this.myTurn = turn;
        rollsLeft = 3;
        hasPlayedThisTurn = false;

        for (int i = 0; i < 6; i++) {
            diceButtons[i].setDisable(!turn);
            diceButtons[i].setSelected(false);
            diceButtons[i].setText("?");
        }

        //fxcon.next.setDisable(!turn);
        fxcon.najava.setDisable(!turn);
        fxcon.handleFinishGame.setDisable(!turn);
        updateRollLabel();
    }

    public void next() {
        pozivSO("next");
        //if (gto.getSignal()) {
        //    setMyTurn(gto.myTurn);
        //} else {
        //    showAlert("Sistem ne može da nađe igrača na osnovu unetih vrednosti za prijavljivanje");
        //}
    }

    public void sacuvajIgru() {
        // Implement saving logic with Partija if needed
    }

    public void pozivSO(String nazivSO) {
        gto.setNazivOperacije(nazivSO);
        try {
            fxcon.out.writeObject(gto);
            //gto = (GenerickiTransferObjekat) fxcon.in.readObject();
        } catch (Exception e) {
            System.err.println("Greška u komunikaciji: " + e.getMessage());
        }
    }

    public void zatvoriFormu() {
        fxcon.zatvoriFormu();
    }

    void rollDice() {
        if (!myTurn || rollsLeft == 0 || hasPlayedThisTurn) {
            return;
        }

        for (int i = 0; i < 6; i++) {
            if (!diceButtons[i].isSelected()) {
                diceValues[i] = random.nextInt(6) + 1;
                diceButtons[i].setText(String.valueOf(diceValues[i]));
            }
        }

        rollsLeft--;
        updateRollLabel();
        updateSumLabel();

        if (rollsLeft == 0) {
            for (ToggleButton btn : diceButtons) {
                btn.setDisable(false);
            }
        }
    }

    void handleFinishGame() {
        //dodaj logiku videcemo posle sta
    }
}

class Server extends Thread
	{ public Server(ObjectInputStream in, ObjectOutputStream out, Korisnik korisnik, GUIKontrolerIgra gkui)
	   { this.in = in;
             this.out = out;
             this.korisnik = korisnik;
             start();
	   }

	  public void run()
	   { try { String signal = "";

                   GenerickiTransferObjekat tok;
                    
	           while (true)
	             { 
                       tok = (GenerickiTransferObjekat) in.readObject();
                       System.out.println("Stigao objekat sa servera na klijent. Naziv operacije: " + tok.nazivOperacije + " Naziv igraca: " + tok.korisnik.getKorisnickoIme() + " Ovo je stiglo klijentu: " + korisnik.getKorisnickoIme());
                     
          	       //out.writeObject(tok);
	             }
	         } catch (Exception e)  { System.out.println("Exception gde sam mislio" + e.getMessage());  }
	   }

	  private
	  ObjectOutputStream out;
          ObjectInputStream in;
          Korisnik korisnik;
          GUIKontrolerIgra gkui;
}
