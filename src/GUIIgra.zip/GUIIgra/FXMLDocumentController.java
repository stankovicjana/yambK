package GUIIgra;

import DomenskiObjekat.Korisnik;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;

public class FXMLDocumentController {

    public ObjectOutputStream out;
    public ObjectInputStream in;
    public Stage stage;

    @FXML
    public GridPane jambTable;
    @FXML
    public Label rollCountLabel;
    @FXML
    public Label sumLabel;
    @FXML
    public ToggleButton dice0, dice1, dice2, dice3, dice4, dice5;
    @FXML
    public Button handleFinishGame;
    @FXML
    public Button next;
    @FXML
    public Button najava;

    public Korisnik korisnik;
    public boolean start;

    private GUIKontrolerIgra kGUI;

    @FXML
    public void initialize() {
    }

    public void initData() {
        kGUI = new GUIKontrolerIgra(this);
        kGUI.init();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setOut(ObjectOutputStream out) {
        this.out = out;
    }

    public void setIn(ObjectInputStream in) {
        this.in = in;
    }

    public void zatvoriFormu() {
        stage.close();
    }

    @FXML
    public void izlazIzPrograma() {
        stage.close();
    }

    @FXML
    private void handleRollDice() {
        if (kGUI != null) {
            kGUI.rollDice();
        }
    }

    @FXML
    private void handleFinishGame() {
        if (kGUI != null) {
            kGUI.handleFinishGame();
        }
    }

    @FXML
    private void handleNajaviPolje() {
        if (kGUI != null) {
            kGUI.handleNajaviPolje();
        }
    }

    @FXML
    private void next() {
        if (kGUI != null) {
            kGUI.next();
        }
    }
}
